import {
  ArrowRight,
  Camera,
  Check,
  Clock,
  Coffee,
  Grid,
  Lock,
  Play,
  RefreshCw,
  Upload,
} from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { getPhotoForLevel } from '../data/photos';
import {
  GameMode,
  LevelConfig,
  LevelProgress,
  Photo,
  ThemeMode,
} from '../types';
import { soundManager } from '../utils/audio';
import { CameraModal } from './CameraModal';

interface StartScreenProps {
  gameMode: GameMode;
  theme: ThemeMode;
  levels: LevelConfig[];
  photos: Photo[];
  progressMap?: Record<number, LevelProgress>;
  onSelectLevel: (levelId: number) => void;
  onOpenLevelSelect: () => void;
  onToggleGameMode: () => void;
  onSelectGameMode: (mode: GameMode) => void;
  onSelectTheme: (theme: ThemeMode) => void;
  onUseDefaultPhotos: () => void;
  onUploadCustomPhotos: (fileList: FileList) => void;
  onUploadPhotoForLevel: (levelId: number, file: File) => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  gameMode,
  theme,
  levels,
  photos,
  progressMap = {},
  onSelectLevel,
  onOpenLevelSelect,
  onSelectGameMode,
  onUseDefaultPhotos,
  onUploadCustomPhotos,
  onUploadPhotoForLevel,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const levelFileInputRef = useRef<HTMLInputElement>(null);
  const [showModeMenu, setShowModeMenu] = useState(false);
  const modeMenuRef = useRef<HTMLDivElement>(null);
  const [uploadTargetLevelId, setUploadTargetLevelId] = useState<number | null>(
    null,
  );

  const [showCameraModal, setShowCameraModal] = useState<boolean>(false);
  const [cameraTargetLevelId, setCameraTargetLevelId] = useState<number | null>(
    null,
  );

  const isUsingCustom = photos.some(
    (p) => p.isCustom && ['photo-1', 'photo-2', 'photo-3'].includes(p.id),
  );

  const safeProgressMap = progressMap || {};

  // Determine which 3 levels to show based on progress
  const completedIds = (
    Object.entries(safeProgressMap) as [string, LevelProgress][]
  )
    .filter(([, p]) => p?.completed)
    .map(([id]) => Number(id));
  const maxCompleted = completedIds.length > 0 ? Math.max(...completedIds) : 0;

  let startIdx = Math.max(0, maxCompleted - 1);
  if (startIdx + 3 > levels.length) startIdx = Math.max(0, levels.length - 3);
  const visibleLevels: LevelConfig[] = levels.slice(startIdx, startIdx + 3);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        modeMenuRef.current &&
        !modeMenuRef.current.contains(e.target as Node)
      ) {
        setShowModeMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      soundManager.playSnap();
      onUploadCustomPhotos(e.target.files);
    }
  };

  const handleLevelFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (
      e.target.files &&
      e.target.files.length > 0 &&
      uploadTargetLevelId !== null
    ) {
      soundManager.playSnap();
      onUploadPhotoForLevel(uploadTargetLevelId, e.target.files[0]);
      setUploadTargetLevelId(null);
      e.target.value = '';
    }
  };

  const triggerLevelUpload = (levelId: number) => {
    setUploadTargetLevelId(levelId);
    setTimeout(() => levelFileInputRef.current?.click(), 50);
  };

  const openCameraForLevel = (levelId?: number) => {
    soundManager.playClick();
    setCameraTargetLevelId(levelId || null);
    setShowCameraModal(true);
  };

  const handleCameraCapture = (dataUrl: string, fileName: string) => {
    setShowCameraModal(false);
    if (cameraTargetLevelId) {
      // Create file object to pass to handler
      fetch(dataUrl)
        .then((res) => res.blob())
        .then((blob) => {
          const file = new File([blob], `${fileName}.jpg`, {
            type: 'image/jpeg',
          });
          onUploadPhotoForLevel(cameraTargetLevelId, file);
        });
    } else {
      // General camera upload for level 1-3
      fetch(dataUrl)
        .then((res) => res.blob())
        .then((blob) => {
          const file = new File([blob], `${fileName}.jpg`, {
            type: 'image/jpeg',
          });
          const dt = new DataTransfer();
          dt.items.add(file);
          onUploadCustomPhotos(dt.files);
        });
    }
  };

  const isLevelUnlocked = (level: LevelConfig): boolean => {
    if (level.id === 1 || level.levelNumber === 1) return true;
    return !!safeProgressMap[level.id - 1]?.completed;
  };

  const hasUploadedPhoto = (level: LevelConfig): boolean => {
    if (!level.requiresUpload) return true;
    const photo = photos.find((p) => p.id === level.photoId);
    return !!photo?.isCustom;
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-3 py-6 flex flex-col items-center justify-center font-['Pixelify_Sans',sans-serif]">
      {/* Hidden File Input for bulk upload (levels 1-3) */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleFileChange}
        className="hidden"
      />
      {/* Hidden File Input for single-level upload (levels 4-7) */}
      <input
        ref={levelFileInputRef}
        type="file"
        accept="image/*"
        onChange={handleLevelFileChange}
        className="hidden"
      />

      {/* Main Pixel Hero Container */}
      <div className="w-full pixel-box p-5 sm:p-8 text-center flex flex-col items-center relative overflow-hidden mb-6">
        <h1 className="font-pixel-title text-xl sm:text-3xl text-theme-title mb-3 leading-tight">
          COZY PIXEL PUZZLE
        </h1>

        <p className="text-xs sm:text-sm text-theme-sub max-w-lg mb-6 leading-relaxed">
          Geser dan susun potongan pixel art cozy di lantai kayu hangat. Bebas
          dimainkan dengan sentuhan jari layar HP/Tablet atau mouse.
        </p>

        {/* Mode Selector */}
        <div
          ref={modeMenuRef}
          className="w-full max-w-md pixel-box-inner p-3 mb-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-left relative"
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 pixel-btn-dark text-theme-title">
              {gameMode === 'relaxed' ? (
                <Coffee className="w-4 h-4" />
              ) : (
                <Clock className="w-4 h-4" />
              )}
            </div>
            <div>
              <div className="font-bold text-xs text-theme-title">
                MODE: {gameMode === 'relaxed' ? 'SANTAI' : 'TANTANGAN'}
              </div>
              <div className="text-[11px] text-theme-sub">
                {gameMode === 'relaxed'
                  ? 'Tanpa timer, main santai.'
                  : 'Timer menghitung waktu terbaik.'}
              </div>
            </div>
          </div>

          <div className="relative w-full sm:w-auto">
            <button
              onClick={() => {
                soundManager.playClick();
                setShowModeMenu((prev) => !prev);
              }}
              className="pixel-btn-dark px-3 py-1.5 text-xs font-bold w-full sm:w-auto flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>PILIH MODE</span>
              <Clock className="w-3.5 h-3.5" />
            </button>

            {/* Mode Dropdown Menu */}
            {showModeMenu && (
              <div className="absolute right-0 mt-2 w-56 pixel-box p-2 z-50 shadow-xl animate-in fade-in zoom-in-95 duration-100">
                <div className="font-pixel-title text-[10px] text-theme-title px-2 py-1 border-b border-theme-inner mb-1.5 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  PILIH MODE GAME:
                </div>

                <div className="flex flex-col gap-1">
                  <button
                    onClick={() => {
                      soundManager.playClick();
                      onSelectGameMode('relaxed');
                      setShowModeMenu(false);
                    }}
                    className={`w-full p-2 text-left text-xs font-bold flex items-center justify-between border transition-all cursor-pointer ${
                      gameMode === 'relaxed'
                        ? 'pixel-box-inner border-theme-title text-theme-title'
                        : 'border-transparent hover:bg-theme-inner text-theme-sub'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Coffee className="w-3.5 h-3.5 text-theme-title" />
                      <div>
                        <div className="leading-tight">MODE SANTAI</div>
                        <div className="text-[10px] font-normal opacity-80">
                          Tanpa timer
                        </div>
                      </div>
                    </div>
                    {gameMode === 'relaxed' && (
                      <Check className="w-3.5 h-3.5 text-theme-title shrink-0" />
                    )}
                  </button>

                  <button
                    onClick={() => {
                      soundManager.playClick();
                      onSelectGameMode('challenge');
                      setShowModeMenu(false);
                    }}
                    className={`w-full p-2 text-left text-xs font-bold flex items-center justify-between border transition-all cursor-pointer ${
                      gameMode === 'challenge'
                        ? 'pixel-box-inner border-theme-title text-theme-title'
                        : 'border-transparent hover:bg-theme-inner text-theme-sub'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-theme-title" />
                      <div>
                        <div className="leading-tight">MODE TANTANGAN</div>
                        <div className="text-[10px] font-normal opacity-80">
                          Timer aktif
                        </div>
                      </div>
                    </div>
                    {gameMode === 'challenge' && (
                      <Check className="w-3.5 h-3.5 text-theme-title shrink-0" />
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Photo Source for levels 1-3 */}
        <div className="w-full max-w-md pixel-box-inner p-3 mb-2 text-left">
          <div className="font-pixel-title text-[10px] text-theme-title mb-2">
            SUMBER FOTO PUZZLE:
          </div>

          <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
            <button
              onClick={() => {
                soundManager.playClick();
                onUseDefaultPhotos();
              }}
              className={`p-2 border-2 text-[11px] font-bold flex items-center justify-center gap-1 transition-all cursor-pointer ${
                !isUsingCustom
                  ? 'border-theme-title bg-theme-main text-theme-title'
                  : 'border-theme-inner bg-theme-wall text-theme-sub hover:bg-theme-main'
              }`}
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>PIXEL</span>
            </button>

            <button
              onClick={() => {
                soundManager.playClick();
                fileInputRef.current?.click();
              }}
              className={`p-2 border-2 text-[11px] font-bold flex items-center justify-center gap-1 transition-all cursor-pointer ${
                isUsingCustom
                  ? 'border-theme-title bg-theme-main text-theme-title'
                  : 'border-theme-inner bg-theme-wall text-theme-sub hover:bg-theme-main'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>UPLOAD</span>
            </button>

            <button
              onClick={() => openCameraForLevel()}
              className="p-2 border-2 border-theme-inner bg-theme-wall text-theme-title hover:bg-theme-main text-[11px] font-bold flex items-center justify-center gap-1 transition-all cursor-pointer"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>KAMERA</span>
            </button>
          </div>

          {isUsingCustom && (
            <div className="mt-2 text-[11px] flex items-center gap-1">
              <Check className="w-3.5 h-3.5" />
              <span>Menggunakan foto buatanmu sendiri!</span>
            </div>
          )}
        </div>
      </div>

      {/* 3 Level Cards Section */}
      <div className="w-full">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 mb-3">
          <div className="font-pixel-title text-xs text-theme-title text-center sm:text-left">
            PILIH LEVEL (1-TAP PLAY):
          </div>

          <button
            onClick={() => {
              soundManager.playClick();
              onOpenLevelSelect();
            }}
            className="pixel-btn px-3 py-1.5 text-xs font-bold flex items-center gap-1.5 cursor-pointer hover:scale-105 transition-transform"
            title="Buka Halaman Pilih Semua Level"
          >
            <Grid className="w-3.5 h-3.5" />
            <span>PILIH LEVEL</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {visibleLevels.map((level) => {
            const photo = getPhotoForLevel(level, photos);
            const unlocked = isLevelUnlocked(level);
            const uploadedPhoto = hasUploadedPhoto(level);
            const completed = !!progressMap[level.id]?.completed;

            return (
              <div
                key={level.id}
                className="pixel-box p-3.5 flex flex-col items-center text-center group hover:border-theme-title transition-all"
              >
                {/* Level Image Preview */}
                <div className="w-full aspect-square pixel-box-inner overflow-hidden mb-3 relative">
                  <img
                    src={photo.url}
                    alt={level.title}
                    className={`w-full h-full object-cover group-hover:scale-105 transition-transform duration-200 ${!unlocked ? 'opacity-40 grayscale' : ''}`}
                  />
                  <div className="absolute top-1 left-1 bg-theme-main border border-theme-title px-1.5 py-0.5 text-[10px] font-bold text-theme-title">
                    {level.gridSize}x{level.gridSize} GRID
                  </div>
                  {completed && (
                    <div className="absolute top-1 right-1 pixel-btn-green text-[10px] font-bold px-1.5 py-0.5 flex items-center gap-1">
                      <Check className="w-3 h-3" />
                      <span>SELESAI</span>
                    </div>
                  )}
                  {!unlocked && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                      <Lock className="w-8 h-8 text-[#FFE17D] drop-shadow-[2px_2px_0px_#000]" />
                    </div>
                  )}
                </div>

                <div className="font-pixel-title text-xs text-theme-title mb-1">
                  {level.title}
                </div>
                <div className="text-xs text-theme-sub mb-3 flex-1">
                  {level.subtitle}
                </div>

                {/* Action button always at bottom */}
                <div className="w-full mt-auto">
                  {!unlocked ? (
                    <div className="w-full pixel-btn-dark py-2 text-xs font-bold flex items-center justify-center gap-1.5 opacity-60 cursor-not-allowed">
                      <Lock className="w-3.5 h-3.5 text-[#dfc7c0]" />
                      <span>TERKUNCI</span>
                    </div>
                  ) : level.requiresUpload && !uploadedPhoto ? (
                    <div className="grid grid-cols-2 gap-1.5 w-full">
                      <button
                        onClick={() => {
                          soundManager.playClick();
                          triggerLevelUpload(level.id);
                        }}
                        className="pixel-btn py-2 text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Upload className="w-3 h-3" />
                        <span>UPLOAD</span>
                      </button>

                      <button
                        onClick={() => openCameraForLevel(level.id)}
                        className="pixel-btn-green py-2 text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Camera className="w-3 h-3" />
                        <span>KAMERA</span>
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        soundManager.playClick();
                        onSelectLevel(level.id);
                      }}
                      className="w-full pixel-btn-green py-2 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Play className="w-4 h-4 fill-current" />
                      <span>MAIN SEKARANG</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Banner Button to Level Select Page */}
        <div className="mt-5 flex justify-center">
          {/* <button
            onClick={() => {
              soundManager.playClick();
              onOpenLevelSelect();
            }}
            className="w-full sm:w-auto pixel-btn px-6 py-2.5 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 cursor-pointer shadow-md hover:scale-105 transition-all"
          >
            <Grid className="w-4 h-4" />
            <span>PILIH LEVEL (LIHAT SEMUA LEVEL)</span>
            <ArrowRight className="w-4 h-4" />
          </button> */}
        </div>
      </div>

      {/* Camera Modal */}
      {showCameraModal && (
        <CameraModal
          onCapturePhoto={handleCameraCapture}
          onClose={() => setShowCameraModal(false)}
        />
      )}
    </div>
  );
};
